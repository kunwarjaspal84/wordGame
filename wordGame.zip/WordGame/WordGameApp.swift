//
//  WordGameApp.swift
//  WordGame
//
//  Created by Kunwardeep Singh on 2021-06-10.
//

import SwiftUI

@main
struct WordGameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
