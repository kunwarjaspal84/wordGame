//
//  ContentView.swift
//  WordGame
//
//  Created by Kunwardeep Singh on 2021-06-10.
//

import SwiftUI

struct ContentView: View {
    @State private var usedWords = [String]()
    @State private var rootWord = ""
    @State private var newWord = ""
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    @State private var showAlert = false
    @State private var score = 0
    var body: some View {
        NavigationView{
            VStack{
                TextField("Enter Your Word Here", text: $newWord, onCommit :addNewWord)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                    .autocapitalization(.none)
                
                List(usedWords, id:\.self){
                    Text($0)
                    Spacer()
                    Image(systemName: "\($0.count).circle.fill")
                }
                Spacer()
                Text("Total Score:\(score)")
            }
            .navigationBarTitle(rootWord)
            .navigationBarItems(leading: Button("New Word", action: startGame))
            .onAppear(perform: startGame)
            .alert(isPresented: $showAlert, content: {
                Alert(title: Text(alertTitle), message: Text(alertMessage), dismissButton: .default(Text("OK")))
            })
        }
    }
    func addNewWord(){
        let answer = newWord.lowercased().trimmingCharacters(in: .whitespaces)
        
        guard answer.count > 0 else {
            return
        }
        guard isOriginal(word: answer) else {
            wordError(title: "Word already used", message: "Be more Original")
            return
        }
        guard isPossible(word: answer) else {
            wordError(title: "Not a word", message: "You cannot just make them up")
            return
        }
        guard isReal(word: answer) else {
            wordError(title: "check your spelling", message: "Work on your vocab man")
            return
        }
        usedWords.insert(answer, at: 0 )
        score = score + answer.count
        newWord = ""
    }
    func startGame(){
        if let startWordsURL = Bundle.main.url(forResource: "start", withExtension: "txt"){
            if let startWord = try? String(contentsOf: startWordsURL){
                let allWords = startWord.components(separatedBy: "\n")
                
                rootWord = allWords.randomElement() ?? "silkworm"
                usedWords.removeAll()
                return
            }
        }
        fatalError("Cannot load start.txt from Bundle")
    }
    func wordError(title:String, message:String){
        alertTitle = title
        alertMessage = message
        showAlert = true
    }
    func isOriginal(word:String) -> Bool{
        !usedWords.contains(word)
    }
    func isPossible(word: String)-> Bool{
        var tempWord = rootWord
        
        for letter in word{
            if let pos = tempWord.firstIndex(of: letter){
                tempWord.remove(at: pos)
            }
            else{
                return false
            }
        }
        return true
    }
    func isReal(word: String) -> Bool{
        if word.count < 3 || word == rootWord {
            return false
        }
        let checker = UITextChecker()
        let range = NSRange(location: 0, length: word.utf16.count)
        let misspelledRange = checker.rangeOfMisspelledWord(in: word, range: range, startingAt: 0, wrap: false, language: "en")
        return misspelledRange.location == NSNotFound
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
